# Author:: Nathaniel Talbott.
# Copyright:: Copyright (c) 2000-2002 Nathaniel Talbott. All rights reserved.
# License:: Ruby license.

require 'test/unit/assertionfailederror.rb'

module RUNIT
  AssertionFailedError = Test::Unit::AssertionFailedError
end
