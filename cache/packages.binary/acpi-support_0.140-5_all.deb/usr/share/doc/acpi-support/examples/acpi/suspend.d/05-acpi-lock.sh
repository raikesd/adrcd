#!/bin/sh

#prevent acpid from processing any following events
touch /var/lock/acpisleep

