#!/bin/sh

##############################################################################
# backup_pgsql.sh
#
# Debian modifications by Antony Gelberg <antony.gelberg@wayforth.com>
#
# by Nathan Rosenquist <nathan@rsnapshot.org>
# http://www.rsnapshot.org/
#
# This is a simple shell script to backup a PostgreSQL database with rsnapshot.
#
# The assumption is that this will be invoked from rsnapshot. Also, since it
# will run unattended, the user that runs rsnapshot (probably root) must su
# to Debian's postgres user.
#
# This script simply needs to dump a file into the current working directory.
# rsnapshot handles everything else.
##############################################################################

# $Id: backup_pgsql.sh,v 1.6 2007/03/22 02:50:21 drhyde Exp $

umask 0077

# backup the database
su -c 'pg_dumpall > ~/pg_dumpall.sql' postgres

# make the backup readable only by root
chown root.root ~postgres/pg_dumpall.sql
chmod 600 ~postgres/pg_dumpall.sql

# Move the backup to current working directory
mv ~postgres/pg_dumpall.sql `pwd`

