# The extension is part of the name of the application
unhide.rb: script-with-language-extension usr/bin/unhide.rb
