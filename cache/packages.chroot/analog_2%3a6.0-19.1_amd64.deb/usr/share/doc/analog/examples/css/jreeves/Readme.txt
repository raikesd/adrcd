Style sheets contributed by James C. Reeves.
