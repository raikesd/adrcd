import GPS
GPS.EditorBuffer.get (GPS.File("README"))
