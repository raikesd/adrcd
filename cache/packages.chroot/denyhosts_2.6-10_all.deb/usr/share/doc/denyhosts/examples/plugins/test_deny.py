#!/usr/bin/python
import sys

print "%s invoked with the following args: %s" % (sys.argv[0], sys.argv[1:])
sys.exit(0)
