#include <stdio.h>

void do_something_else (void) {
    printf ("Doing something else in C \n");
}
