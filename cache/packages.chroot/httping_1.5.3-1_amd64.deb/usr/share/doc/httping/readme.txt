Installation:
------------
make install

to build without SSL support:
make -f Makefile.nossl install


Usage:
-----
httping www.vanheusden.com


Thanks to Thanatos for cookie and authentication support.


For everything more or less related to 'httping', please feel free
to contact me on: folkert@vanheusden.com
Consider using PGP. My PGP key-id is: 0x1f28d8ae

Please support my opensource development: http://www.vanheusden.com/wishlist.php
