**-Unhide-**   
               http://www.unhide-forensics.info

Unhide is a forensic tool to find hidden processes and TCP/UDP ports by rootkits / LKMs
or by another hiding technique.

// Unhide (ps)
// -----------

Detecting hidden processes. Implements six main techniques

1- Compare /proc vs /bin/ps output

2- Compare info gathered from /bin/ps with info gathered by walking thru the procfs. ONLY for Linux 2.6 version

3- Compare info gathered from /bin/ps with info gathered from syscalls (syscall scanning).

4- Full PIDs space ocupation (PIDs bruteforcing). ONLY for Linux 2.6 version

5- Compare /bin/ps output vs /proc, procfs walking and syscall. ONLY for Linux 2.6 version
   Reverse search, verify that all thread seen by ps are also seen in the kernel.

6- Quick compare /proc, procfs walking and syscall vs /bin/ps output. ONLY for Linux 2.6 version
  It's about 20 times faster than tests 1+2+3 but maybe give more false positives.

// Unhide-TCP
// ----------

Identify TCP/UDP ports that are listening but not listed in /bin/netstat doing brute forcing
of all TCP/UDP ports availables.


// Files
// -----

unhide.c --> Hidden processes, for generic Unix systems (*BSD, Solaris, linux 2.2 / 2.4)
             It doesn't implement PIDs brute forcing check yet. Needs more testing
             Warning : This version is somewhat outdated and may generate false positive.
                       Prefer unhide-linux26.c if you can use it.

unhide-linux26.c --> Hidden processes, for Linux 2.6.x

unhide-tcp.c --> Hidden TCP/UDP Ports

changelog - As the name implied log of the change to unhide

COPYING - License file, GNU GPL V3

LEEME.txt - Spanish version of this file

LISEZ-MOI.TXT - French version of this file

README.txt - This file

sanity.sh - unhide-linux26 testsuite file

TODO - Evolutions to do (any volunteers ?)

man/unhide.8 - English man page of unhide

man/unhide-tcp.8 - English man page of unhide-tcp

man/fr/unhide.8 - French man page of unhide


// Compiling
// ---------

gcc --static unhide.c -o unhide

gcc --static unhide-tcp.c -o unhide-tcp

gcc -Wall -O2 --static -pthread unhide-linux26.c -o unhide-linux26

// License

GPL V.3 (http://www.gnu.org/licenses/gpl-3.0.html)

// Greets
// ------

A. Ramos (aramosf@unsec.net) for some regexps

unspawn (unspawn@rootshell.be) CentOS support

Martin Bowers (Martin.Bowers@freescale.com) CentOS support

Lorenzo Martinez (lorenzo@lorenzomartinez.homeip.net) Some ideas to improve and betatesting

Francois Marier (francois@debian.org) Author of the man pages and Debian support

Johan Walles (johan.walles@gmail.com) Find and fix a very nasty race condition bug

Jan Iven (jan.iven@cern.ch) Because of his great improvements, new tests and bugfixing

P. Gouin (pg.bug.cvs.pgn@free.fr) Because of his incredible work fixing bugs and improving the performance
